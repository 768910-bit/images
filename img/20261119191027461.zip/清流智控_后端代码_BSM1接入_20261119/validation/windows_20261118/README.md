# Windows 四档复跑验证

验证日期：2026-11-18

## 环境

- 操作系统：Windows
- Python：3.12.14，64 位
- 使用交接包内的 `.venv`
- `pip check`：No broken requirements found
- 完整依赖清单：`pip_freeze.txt`

## 执行

- `INSTALL_WINDOWS.bat`：退出码 0
- `RUN_FOUR_CASES.bat`：退出码 0
- 安装日志：`install_windows.log`
- 四档控制台日志：`run_four_cases_console.log`
- 四档脚本日志：`four_cases/kla_84.log` 至 `four_cases/kla_195.log`
- 四档汇总：`four_cases/plans.json`

## 结果

| KLa5 | 氨氮均值 | 氨氮 P95 | 超参考线时长 | 日均曝气能耗 | 低于参考线 |
| --- | ---: | ---: | ---: | ---: | --- |
| 84 | 6.0450 | 11.3916 | 17.79 h/天 | 3341.39 kWh/天 | 否 |
| 180 | 4.0302 | 8.3322 | 11.32 h/天 | 3910.13 kWh/天 | 否 |
| 185 | 3.9953 | 8.2814 | 11.11 h/天 | 3939.76 kWh/天 | 是 |
| 195 | 3.9330 | 8.1882 | 10.71 h/天 | 3999.00 kWh/天 | 是 |

筛选结果为 `kla-185`。

## 与现有验证记录核对

- 四档全部指标与 `validation/reproduced_20261118/plans.json` 一致。
- 四份日志按文本行比较完全一致。
- Windows 新日志使用 CRLF，Linux 原验证日志使用 LF，因此文件字节哈希不同；内容和数值一致。
- 逐项结论见 `comparison_to_validation.json`。

## 校验值

- 打包文件校验：200 个清单文件全部匹配。
- 运行脚本 SHA256：`9dbdedf714b8643b1bc65e3d68d374325207b3f3b985bb40074d00cc4eb74f3f`
- 进水文件 SHA256：`34df5e3fc9140186f7bcb6a1f5111a792046f108ac00d2876dde77230d7fb9d0`
- 提交原表 SHA256：`1289e782da0e41e90bc554d81d73c0bb32d1d63cd3c731c276e4129ed17ffc55`
- 详细记录：`data_checksums.json`
