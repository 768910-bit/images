from dotenv import load_dotenv

load_dotenv()

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.router import api_router
from app.db import init_db
from app.realtime.websocket import router as realtime_router


init_db()

app = FastAPI(
    title="清流智控 API",
    description="污水处理运行监测与曝气优化平台后端接口",
    version="0.1.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://127.0.0.1:5173",
        "http://localhost:5173",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(api_router, prefix="/api")
app.include_router(realtime_router)


@app.get("/", tags=["system"])
def root() -> dict[str, str]:
    return {
        "message": "清流智控 API 已启动",
        "docs": "/docs",
    }
