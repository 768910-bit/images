from io import BytesIO
from pathlib import Path
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (
    KeepTogether,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

from app.schemas.report import DailyReport, ReportItem


_BODY_FONT = "STSong-Light"
_FONT_FILE_CANDIDATES = (
    Path("C:/Windows/Fonts/simhei.ttf"),
    Path("/usr/share/fonts/truetype/arphic/uming.ttc"),
)


def _ensure_font() -> None:
    global _BODY_FONT
    if _BODY_FONT in pdfmetrics.getRegisteredFontNames():
        return

    font_path = next(
        (path for path in _FONT_FILE_CANDIDATES if path.is_file()),
        None,
    )
    if font_path is not None and font_path.suffix.lower() == ".ttf":
        pdfmetrics.registerFont(TTFont("AquaOpsCJK", str(font_path)))
        _BODY_FONT = "AquaOpsCJK"
        return

    pdfmetrics.registerFont(UnicodeCIDFont("STSong-Light"))
    _BODY_FONT = "STSong-Light"


def _paragraph(text: str, style: ParagraphStyle) -> Paragraph:
    normalized = (
        text.replace("m³", "m3")
        .replace("kW·h", "kWh")
        .replace("×", "x")
        .replace("–", "-")
    )
    return Paragraph(escape(normalized), style)


def _add_page_number(canvas, document) -> None:
    canvas.saveState()
    canvas.setFont(_BODY_FONT, 8)
    canvas.setFillColor(colors.HexColor("#64748b"))
    canvas.drawString(18 * mm, 10 * mm, "清流智控 · 运行日报")
    canvas.drawRightString(
        A4[0] - 18 * mm,
        10 * mm,
        f"第 {document.page} 页",
    )
    canvas.restoreState()


def build_daily_report_pdf(
    daily_report: DailyReport,
    report: ReportItem,
) -> bytes:
    _ensure_font()
    buffer = BytesIO()
    document = SimpleDocTemplate(
        buffer,
        pagesize=A4,
        rightMargin=18 * mm,
        leftMargin=18 * mm,
        topMargin=18 * mm,
        bottomMargin=18 * mm,
        title=report.title,
        author="清流智控",
        subject=f"运行日报 {report.period}",
    )

    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        "ReportTitle",
        parent=styles["Title"],
        fontName=_BODY_FONT,
        fontSize=23,
        leading=31,
        textColor=colors.HexColor("#0f4c5c"),
        alignment=TA_LEFT,
        spaceAfter=4 * mm,
    )
    eyebrow_style = ParagraphStyle(
        "Eyebrow",
        parent=styles["Normal"],
        fontName=_BODY_FONT,
        fontSize=9,
        leading=12,
        textColor=colors.HexColor("#0f766e"),
        spaceAfter=2 * mm,
    )
    heading_style = ParagraphStyle(
        "SectionHeading",
        parent=styles["Heading2"],
        fontName=_BODY_FONT,
        fontSize=13,
        leading=18,
        textColor=colors.HexColor("#0f4c5c"),
        spaceBefore=5 * mm,
        spaceAfter=2.5 * mm,
    )
    body_style = ParagraphStyle(
        "Body",
        parent=styles["BodyText"],
        fontName=_BODY_FONT,
        fontSize=10,
        leading=17,
        textColor=colors.HexColor("#334155"),
    )
    meta_label_style = ParagraphStyle(
        "MetaLabel",
        parent=body_style,
        fontSize=9,
        textColor=colors.HexColor("#64748b"),
    )
    meta_value_style = ParagraphStyle(
        "MetaValue",
        parent=body_style,
        fontSize=9.5,
        textColor=colors.HexColor("#0f172a"),
    )
    metric_label_style = ParagraphStyle(
        "MetricLabel",
        parent=body_style,
        fontSize=8.5,
        leading=11,
        textColor=colors.HexColor("#64748b"),
        alignment=TA_CENTER,
    )
    metric_value_style = ParagraphStyle(
        "MetricValue",
        parent=body_style,
        fontName="Helvetica",
        fontSize=15,
        leading=20,
        textColor=colors.HexColor("#0f172a"),
        alignment=TA_CENTER,
    )
    trend_style = ParagraphStyle(
        "Trend",
        parent=body_style,
        fontSize=9,
        leading=12,
        textColor=colors.HexColor("#0f766e"),
        alignment=TA_CENTER,
    )

    story = [
        _paragraph("清流智控", eyebrow_style),
        _paragraph(report.title, title_style),
        _paragraph(
            f"{daily_report.title} · {report.period}",
            body_style,
        ),
        Spacer(1, 4 * mm),
    ]

    metadata = Table(
        [
            [
                _paragraph("报告编号", meta_label_style),
                _paragraph(report.id, meta_value_style),
                _paragraph("生成时间", meta_label_style),
                _paragraph(report.generatedAt, meta_value_style),
            ],
            [
                _paragraph("报告周期", meta_label_style),
                _paragraph(report.period, meta_value_style),
                _paragraph("状态", meta_label_style),
                _paragraph("已生成", meta_value_style),
            ],
        ],
        colWidths=[24 * mm, 55 * mm, 24 * mm, 55 * mm],
    )
    metadata.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#f1f5f9")),
                ("BOX", (0, 0), (-1, -1), 0.5, colors.HexColor("#cbd5e1")),
                ("INNERGRID", (0, 0), (-1, -1), 0.35, colors.HexColor("#e2e8f0")),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ("LEFTPADDING", (0, 0), (-1, -1), 3 * mm),
                ("RIGHTPADDING", (0, 0), (-1, -1), 3 * mm),
                ("TOPPADDING", (0, 0), (-1, -1), 2.4 * mm),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 2.4 * mm),
            ]
        )
    )
    story.extend([metadata, _paragraph("运行摘要", heading_style)])
    story.extend(
        _paragraph(f"- {summary}", body_style)
        for summary in daily_report.summary
    )

    metric_cells = []
    for metric in daily_report.metrics:
        metric_cells.append(
            [
                _paragraph(metric.label, metric_label_style),
                _paragraph(metric.value, metric_value_style),
                _paragraph(f"较基准 {metric.trend}", trend_style),
            ]
        )
    metrics_table = Table(
        [metric_cells],
        colWidths=[39.5 * mm] * 4,
    )
    metrics_table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#f8fafc")),
                ("BOX", (0, 0), (-1, -1), 0.5, colors.HexColor("#dbe4ea")),
                ("INNERGRID", (0, 0), (-1, -1), 0.35, colors.HexColor("#e2e8f0")),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ("TOPPADDING", (0, 0), (-1, -1), 3.5 * mm),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 3.5 * mm),
            ]
        )
    )
    story.extend(
        [
            _paragraph("核心指标", heading_style),
            metrics_table,
            Spacer(1, 5 * mm),
            KeepTogether(
                [
                    _paragraph("报告说明", heading_style),
                    _paragraph(
                        "本报告由清流智控根据已接入的运行数据自动生成，"
                        "供运行复盘和辅助决策使用。",
                        body_style,
                    ),
                    _paragraph(
                        "数据口径以系统采集记录为准。",
                        body_style,
                    ),
                    Spacer(1, 3 * mm),
                    _paragraph(
                        f"系统生成时间：{daily_report.generatedAt}",
                        meta_label_style,
                    ),
                ]
            ),
        ]
    )

    document.build(
        story,
        onFirstPage=_add_page_number,
        onLaterPages=_add_page_number,
    )
    return buffer.getvalue()
