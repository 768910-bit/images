from datetime import UTC, datetime

from fastapi import HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models import AlarmRecord
from app.schemas.alarm import AcknowledgeAlarmRequest, Alarm


def _to_alarm(record: AlarmRecord) -> Alarm:
    return Alarm(
        id=record.id,
        level=record.level,
        title=record.title,
        source=record.source,
        triggeredAt=record.triggered_at,
        receivedAt=record.received_at,
        status=record.status,
        cause=record.cause,
        suggestion=record.suggestion,
        expectedAt=record.expected_at,
        owner=record.owner,
    )


def list_alarms(session: Session) -> list[Alarm]:
    records = session.scalars(
        select(AlarmRecord).order_by(AlarmRecord.triggered_at.desc())
    ).all()
    return [_to_alarm(record) for record in records]


def acknowledge_alarm(
    session: Session,
    alarm_id: str,
    payload: AcknowledgeAlarmRequest,
) -> Alarm:
    record = session.get(AlarmRecord, alarm_id)
    if record is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="未找到告警",
        )

    record.status = "acknowledged"
    record.owner = payload.owner
    record.acknowledge_note = payload.note
    record.acknowledged_at = datetime.now(UTC)
    session.commit()
    session.refresh(record)
    return _to_alarm(record)
