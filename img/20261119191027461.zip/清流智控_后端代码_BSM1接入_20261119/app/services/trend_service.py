import math
from datetime import datetime, timedelta

from app.schemas.monitoring import TrendPoint, TrendRange, TrendSeries


_range_config = {
    "1h": {"points": 13, "step_minutes": 5},
    "24h": {"points": 25, "step_minutes": 60},
    "7d": {"points": 15, "step_minutes": 720},
}


def _time_label(value: datetime, time_range: TrendRange) -> str:
    if time_range == "7d":
        return value.strftime("%m-%d")
    return value.strftime("%H:%M")


def _create_wave(
    *,
    time_range: TrendRange,
    base: float,
    amplitude: float,
    seed: float,
    anomaly_boost: float = 0,
) -> list[TrendPoint]:
    config = _range_config[time_range]
    point_count = config["points"]
    step_minutes = config["step_minutes"]
    now = datetime.now().astimezone().replace(second=0, microsecond=0)
    now = now.replace(minute=(now.minute // 5) * 5)
    data: list[TrendPoint] = []

    for index in range(point_count):
        offset = timedelta(minutes=(point_count - 1 - index) * step_minutes)
        timestamp = now - offset
        wave = math.sin((index + seed) * 0.78) * amplitude
        fine = math.cos((index + seed * 2) * 1.7) * amplitude * 0.28
        anomaly = 0.0
        if anomaly_boost and point_count * 0.56 < index < point_count * 0.8:
            anomaly = math.sin((index - point_count * 0.56) * 1.1) * anomaly_boost

        data.append(
            TrendPoint(
                time=_time_label(timestamp, time_range),
                value=round(base + wave + fine + anomaly, 2),
            )
        )

    return data


def create_trend_series(time_range: TrendRange) -> list[TrendSeries]:
    return [
        TrendSeries(
            id="cod",
            name="进水 COD",
            unit="mg/L",
            color="#2475a7",
            threshold=300,
            data=_create_wave(
                time_range=time_range,
                base=268,
                amplitude=13,
                seed=1.4,
                anomaly_boost=8,
            ),
        ),
        TrendSeries(
            id="ammonia",
            name="进水氨氮",
            unit="mg/L",
            color="#d97706",
            threshold=18,
            data=_create_wave(
                time_range=time_range,
                base=14.7,
                amplitude=1.9,
                seed=3.2,
                anomaly_boost=2.1,
            ),
        ),
        TrendSeries(
            id="do",
            name="好氧池 DO",
            unit="mg/L",
            color="#087d68",
            threshold=2.5,
            data=_create_wave(
                time_range=time_range,
                base=2.58,
                amplitude=0.16,
                seed=2.1,
            ),
        ),
        TrendSeries(
            id="flow",
            name="瞬时流量",
            unit="m³/h",
            color="#5d6f9c",
            threshold=1400,
            data=_create_wave(
                time_range=time_range,
                base=1170,
                amplitude=54,
                seed=0.8,
                anomaly_boost=28,
            ),
        ),
        TrendSeries(
            id="ph",
            name="进水 pH",
            unit="",
            color="#6b8d65",
            threshold=9,
            data=_create_wave(
                time_range=time_range,
                base=7.22,
                amplitude=0.13,
                seed=4.1,
            ),
        ),
        TrendSeries(
            id="temperature",
            name="水温",
            unit="°C",
            color="#a55d45",
            threshold=30,
            data=_create_wave(
                time_range=time_range,
                base=21.3,
                amplitude=0.55,
                seed=5.3,
            ),
        ),
    ]
