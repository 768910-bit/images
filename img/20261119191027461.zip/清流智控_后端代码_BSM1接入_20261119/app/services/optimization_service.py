import json
from functools import lru_cache
from pathlib import Path
from typing import Any

from app.schemas.optimization import (
    OptimizationDataSource,
    OptimizationPlan,
    OptimizationPlanMetrics,
    OptimizationPlansResponse,
    OptimizationSourceInfo,
)


_DATA_DIR = Path(__file__).resolve().parents[1] / "data" / "bsm1_handoff"
_SOURCE_FILES: dict[OptimizationDataSource, str] = {
    "submittedWorkbook": "submitted_plans.json",
    "reproducedWithPackagedScript": "reproduced_plans.json",
}
_DEFAULT_SOURCE: OptimizationDataSource = "submittedWorkbook"
_SELECTION_RULE = (
    "在已测方案中，先筛选流量加权均值严格低于 4 mg N/L 的候选，"
    "再选择日均曝气能耗最低者。"
)


def optimization_plans_snapshot_key(
    source: OptimizationDataSource,
) -> str:
    return f"optimization.plans.bsm1-handoff.windows-20261118.{source}"


@lru_cache(maxsize=2)
def _load_source_payload(source: OptimizationDataSource) -> dict[str, Any]:
    path = _DATA_DIR / _SOURCE_FILES[source]
    payload = json.loads(path.read_text(encoding="utf-8"))
    if payload.get("source") != source:
        raise ValueError(f"{path.name} 的来源标识与请求来源不一致")
    plans = payload.get("plans")
    if not isinstance(plans, list) or len(plans) != 4:
        raise ValueError(f"{path.name} 应包含四档方案")
    return payload


def _source_info(source: OptimizationDataSource) -> OptimizationSourceInfo:
    payload = _load_source_payload(source)
    if source == "submittedWorkbook":
        return OptimizationSourceInfo(
            source=source,
            label="学姐提交原表",
            sourceFile=payload["sourceFile"],
            runSettingsVerified=False,
            generatedAt="2026-11-17T00:00:00+08:00",
            note="原表只保留了汇总数，生成模型、进水文件和运行命令未完整记录。",
        )

    return OptimizationSourceInfo(
        source=source,
        label="本包脚本复跑",
        sourceFile="validation/reproduced_20261118/plans.json",
        influentFile=payload.get("influentFile"),
        modelSnapshot=(
            f"{payload.get('model', 'BSM1OL')} / "
            f"script {str(payload.get('scriptSha256', ''))[:8]}"
        ),
        runSettingsVerified=True,
        generatedAt=payload["generatedAt"],
        note=(
            "在 Windows 与 Python 3.12.14 环境中使用 raininfluent_clean.csv "
            "和打包脚本完成四档端到端复跑。"
        ),
    )


def _build_plan(
    *,
    source: OptimizationDataSource,
    item: dict[str, Any],
) -> OptimizationPlan:
    metrics = item["metrics"]
    kla_per_day = item.get("klaPerDay")
    kla5_value = item.get("kla5")
    if kla5_value is None:
        if not kla_per_day:
            raise ValueError(f"{item.get('id', 'unknown')} 缺少 KLa5")
        kla5_value = kla_per_day[-1]
    kla5 = float(kla5_value)
    curve = item.get("curve")
    curve_status = item.get("curveStatus") or (
        "available" if curve is not None else "notExported"
    )

    if source == "submittedWorkbook":
        model = "原表转录"
        operating_condition = "原表未记录进水文件与模型快照"
    else:
        model = "BSM1OL"
        operating_condition = "raininfluent_clean.csv，最后 7 天评价窗口"

    return OptimizationPlan(
        id=item["id"],
        name=item["name"],
        source=source,
        model=model,
        operatingCondition=operating_condition,
        kla5=kla5,
        klaPerDay=kla_per_day,
        metrics=OptimizationPlanMetrics(
            ammoniaMean=float(metrics["ammoniaMean"]),
            ammoniaP95=float(metrics["ammoniaP95"]),
            overReferenceHoursPerDay=float(
                metrics["overReferenceHoursPerDay"]
            ),
            dailyEnergy=float(metrics["dailyEnergy"]),
        ),
        belowReference=bool(item["belowReference"]),
        curve=None,
        curveStatus=curve_status,
        logFile=item.get("logFile"),
    )


def get_optimization_plans(
    source: OptimizationDataSource = _DEFAULT_SOURCE,
) -> OptimizationPlansResponse:
    payload = _load_source_payload(source)
    plans = [
        _build_plan(source=source, item=item)
        for item in payload["plans"]
    ]
    return OptimizationPlansResponse(
        updatedAt=_source_info(source).generatedAt,
        source=source,
        availableSources=[
            _source_info("submittedWorkbook"),
            _source_info("reproducedWithPackagedScript"),
        ],
        selectedId=payload["selectedId"],
        selectionRule=_SELECTION_RULE,
        plans=plans,
    )
