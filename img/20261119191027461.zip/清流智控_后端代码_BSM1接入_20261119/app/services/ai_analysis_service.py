import math
from datetime import datetime

from fastapi import HTTPException, status
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.models import AIAnalysisTaskRecord, SavedAnalysisRecord
from app.schemas.ai_analysis import (
    AIAnalysisCurve,
    AIAnalysisCurvePoint,
    AIAnalysisMetric,
    AIAnalysisResult,
    AIAnalysisSuggestion,
    AIAnalysisTask,
    AnalysisRange,
    SavedAnalysisResponse,
)


def _build_curve(
    *,
    curve_id: str,
    name: str,
    unit: str,
    color: str,
    baseline: float,
    amplitude: float,
    phase: float,
) -> AIAnalysisCurve:
    points = []
    for index in range(25):
        value = baseline + amplitude * math.sin(index / 3 + phase)
        points.append(
            AIAnalysisCurvePoint(
                time=f"{index:02d}:00",
                value=round(max(value, 0), 2),
            )
        )
    return AIAnalysisCurve(
        id=curve_id,
        name=name,
        unit=unit,
        color=color,
        data=points,
    )


def _build_result() -> AIAnalysisResult:
    return AIAnalysisResult(
        score=86.0,
        tip="进水冲击期间，先稳住好氧池 DO 再谈节能。",
        metrics=[
            AIAnalysisMetric(label="进水流量", value="1,246 m³/h"),
            AIAnalysisMetric(label="出水氨氮均值", value="4.82 mg N/L"),
            AIAnalysisMetric(label="DO 达标时长", value="91.7%"),
        ],
        suggestions=[
            AIAnalysisSuggestion(
                kind="training",
                title="优化建议",
                detail="将 3、4 号池鼓风机负荷提高 6%，把 DO 稳定在 2.6~2.9 mg/L。",
            ),
            AIAnalysisSuggestion(
                kind="warning",
                title="风险动作建议",
                detail="未来 40 分钟避免同时降低曝气量，防止氨氮触及 5 mg/L 控制线。",
            ),
        ],
        curve=[
            _build_curve(
                curve_id="ammonia",
                name="进水氨氮",
                unit="mg/L",
                color="#d97706",
                baseline=18.6,
                amplitude=3.1,
                phase=0.2,
            ),
            _build_curve(
                curve_id="do",
                name="好氧池 DO",
                unit="mg/L",
                color="#2563eb",
                baseline=2.55,
                amplitude=0.32,
                phase=1.1,
            ),
        ],
    )


def start_analysis(session: Session, analysis_range: AnalysisRange) -> str:
    now = datetime.now().astimezone()
    task_count = session.scalar(
        select(func.count()).select_from(AIAnalysisTaskRecord)
    ) or 0
    task_id = f"AI-{now:%Y%m%d}-{task_count + 1:03d}"
    session.add(
        AIAnalysisTaskRecord(
            task_id=task_id,
            analysis_range=analysis_range,
            status="running",
        )
    )
    session.commit()
    return task_id


def get_analysis_task(session: Session, task_id: str) -> AIAnalysisTask:
    record = session.get(AIAnalysisTaskRecord, task_id)
    if record is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="未找到分析任务",
        )

    if record.progress < 100:
        record.progress = min(100, record.progress + 34)
        record.analyzed_points = round(827 * record.progress / 100)

    if record.progress == 100 and record.result is None:
        record.result = _build_result().model_dump(mode="json")
        record.status = "done"

    session.commit()
    session.refresh(record)
    return AIAnalysisTask(
        status=record.status,
        progress=record.progress,
        analyzedPoints=record.analyzed_points,
        result=(
            AIAnalysisResult.model_validate(record.result)
            if record.result is not None
            else None
        ),
    )


def save_analysis(session: Session, task_id: str) -> SavedAnalysisResponse:
    task = session.get(AIAnalysisTaskRecord, task_id)
    if task is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="未找到分析任务",
        )
    if task.progress < 100:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="分析尚未完成，暂不能保存",
        )

    saved = session.scalar(
        select(SavedAnalysisRecord).where(SavedAnalysisRecord.task_id == task_id)
    )
    if saved is None:
        record_count = session.scalar(
            select(func.count()).select_from(SavedAnalysisRecord)
        ) or 0
        saved = SavedAnalysisRecord(
            id=f"AIS-{datetime.now().astimezone():%Y%m%d}-{record_count + 1:03d}",
            task_id=task_id,
        )
        session.add(saved)
        session.commit()
        session.refresh(saved)

    return SavedAnalysisResponse(id=saved.id)
