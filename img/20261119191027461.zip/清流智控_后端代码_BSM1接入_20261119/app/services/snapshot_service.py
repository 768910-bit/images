from typing import Any

from sqlalchemy.orm import Session

from app.models import BusinessSnapshot


def read_snapshot(session: Session, key: str) -> dict[str, Any] | None:
    snapshot = session.get(BusinessSnapshot, key)
    return snapshot.payload if snapshot is not None else None


def write_snapshot(session: Session, key: str, payload: dict[str, Any]) -> None:
    snapshot = session.get(BusinessSnapshot, key)
    if snapshot is None:
        session.add(BusinessSnapshot(key=key, payload=payload))
    else:
        snapshot.payload = payload
    session.commit()
