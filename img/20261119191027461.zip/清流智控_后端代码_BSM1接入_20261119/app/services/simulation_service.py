import time
from datetime import datetime

from app.schemas.common import RiskLevel
from app.schemas.simulation import (
    SimulationInput,
    SimulationResult,
    SimulationScenarioResult,
    SimulationTimelinePoint,
)


def _risk_from_compliance(compliance: float) -> RiskLevel:
    if compliance < 94:
        return "critical"
    if compliance < 97.5:
        return "warning"
    return "attention"


def _optimized_risk_from_compliance(compliance: float) -> RiskLevel:
    if compliance < 94:
        return "warning"
    if compliance < 97.5:
        return "attention"
    return "normal"


def run_simulation(payload: SimulationInput) -> SimulationResult:
    load_factor = (
        (payload.flow / 1200) * 0.36
        + (payload.cod / 260) * 0.34
        + (payload.ammonia / 16) * 0.3
    )
    cold_penalty = max(0, (16 - payload.temperature) * 1.2)
    current_compliance = max(
        82.6,
        min(99.5, 99.2 - (load_factor - 1) * 10.4 - cold_penalty),
    )
    optimized_compliance = max(
        88.2,
        min(99.7, 99.6 - (load_factor - 1) * 6.8 - cold_penalty * 0.45),
    )
    current_energy = round(4860 * (0.86 + load_factor * 0.17))
    optimized_multiplier = 0.89 if payload.strategy == "optimized" else 0.96
    optimized_energy = round(current_energy * optimized_multiplier)

    timeline: list[SimulationTimelinePoint] = []
    for index in range(7):
        lift = 0.36 if payload.strategy == "optimized" else 0.12
        timeline.append(
            SimulationTimelinePoint(
                time=f"{index}h",
                currentDO=round(
                    2.35 - min(0.72, index * 0.08) + load_factor * 0.04,
                    2,
                ),
                optimizedDO=round(2.35 + min(lift, index * 0.06), 2),
                currentAmmonia=round(
                    3.6 + max(0, load_factor - 1) * index * 1.28,
                    2,
                ),
                optimizedAmmonia=round(
                    3.6 + max(0, load_factor - 1) * index * 0.42,
                    2,
                ),
            )
        )

    if payload.strategy == "optimized":
        summary = "优化策略可抵消本次进水冲击的大部分风险，建议将鼓风机负荷提前提高。"
    else:
        summary = "当前策略在冲击负荷下存在出水氨氮超标风险，建议切换至优化策略。"

    return SimulationResult(
        runId=f"SIM-{int(time.time() * 1000) % 100_000_000:08d}",
        createdAt=datetime.now().astimezone().strftime("%H:%M:%S"),
        summary=summary,
        current=SimulationScenarioResult(
            energy=current_energy,
            compliance=round(current_compliance, 1),
            risk=_risk_from_compliance(current_compliance),
            doStability=round(86 - max(0, load_factor - 1) * 18, 1),
        ),
        optimized=SimulationScenarioResult(
            energy=optimized_energy,
            compliance=round(optimized_compliance, 1),
            risk=_optimized_risk_from_compliance(optimized_compliance),
            doStability=round(94 - max(0, load_factor - 1) * 7, 1),
        ),
        timeline=timeline,
    )
