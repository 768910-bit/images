from fastapi import APIRouter, Depends

from app.api.routes import (
    ai_analysis,
    alarms,
    auth,
    dashboard,
    health,
    monitoring,
    optimization,
    process,
    reports,
    simulation,
)
from app.api.deps import require_user


api_router = APIRouter()
api_router.include_router(health.router)
api_router.include_router(auth.router, prefix="/auth", tags=["auth"])
protected_dependencies = [Depends(require_user)]
api_router.include_router(
    dashboard.router,
    prefix="/dashboard",
    tags=["dashboard"],
    dependencies=protected_dependencies,
)
api_router.include_router(
    process.router,
    prefix="/process",
    tags=["process"],
    dependencies=protected_dependencies,
)
api_router.include_router(
    monitoring.router,
    prefix="/monitoring",
    tags=["monitoring"],
    dependencies=protected_dependencies,
)
api_router.include_router(
    alarms.router,
    prefix="/alarms",
    tags=["alarms"],
    dependencies=protected_dependencies,
)
api_router.include_router(
    optimization.router,
    prefix="/optimization",
    tags=["optimization"],
    dependencies=protected_dependencies,
)
api_router.include_router(
    simulation.router,
    prefix="/simulation",
    tags=["simulation"],
    dependencies=protected_dependencies,
)
api_router.include_router(
    reports.router,
    prefix="/reports",
    tags=["reports"],
    dependencies=protected_dependencies,
)
api_router.include_router(
    ai_analysis.router,
    prefix="/ai-analysis",
    tags=["ai-analysis"],
    dependencies=protected_dependencies,
)
