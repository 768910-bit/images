from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.db import get_db
from app.models import UserRecord
from app.security import TokenValidationError, decode_access_token


bearer_scheme = HTTPBearer(
    auto_error=False,
    scheme_name="BearerAuth",
    description="使用登录接口返回的 Bearer Token",
)


def resolve_user_from_token(session: Session, token: str) -> UserRecord | None:
    try:
        claims = decode_access_token(token)
    except TokenValidationError:
        return None

    user = session.scalar(
        select(UserRecord).where(UserRecord.account == claims.account)
    )
    if user is None or not user.is_active:
        return None
    return user


def require_user(
    credentials: HTTPAuthorizationCredentials | None = Depends(bearer_scheme),
    session: Session = Depends(get_db),
) -> UserRecord:
    if credentials is None or credentials.scheme.lower() != "bearer":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="缺少访问令牌",
            headers={"WWW-Authenticate": "Bearer"},
        )

    user = resolve_user_from_token(session, credentials.credentials)
    if user is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="访问令牌无效或已过期",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return user
