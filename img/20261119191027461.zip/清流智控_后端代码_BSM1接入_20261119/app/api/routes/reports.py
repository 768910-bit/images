from datetime import datetime, timedelta

from fastapi import APIRouter, HTTPException
from fastapi.responses import Response

from app.data.mock_data import DAILY_REPORT
from app.schemas.report import DailyReport
from app.services.report_pdf import build_daily_report_pdf


router = APIRouter()


def build_daily_report() -> DailyReport:
    now = datetime.now().astimezone()
    periods = [now.date() - timedelta(days=offset) for offset in range(3)]
    reports = []

    for index, period in enumerate(periods):
        report_date = period.strftime("%Y-%m-%d")
        template = DAILY_REPORT.reports[index]
        generated_at = (
            f"今天 {now:%H:%M}"
            if index == 0
            else template.generatedAt
        )
        reports.append(
            template.model_copy(
                update={
                    "id": f"RPT-{period:%Y%m%d}",
                    "title": f"运行日报（{period.month} 月 {period.day} 日）",
                    "period": report_date,
                    "generatedAt": generated_at,
                }
            )
        )

    return DAILY_REPORT.model_copy(
        update={
            "id": reports[0].id,
            "date": f"{now.year} 年 {now.month} 月 {now.day} 日",
            "reports": reports,
            "generatedAt": now.isoformat(timespec="seconds"),
        }
    )


@router.get("/daily", response_model=DailyReport)
def get_daily_report() -> DailyReport:
    return build_daily_report()


@router.get("/{report_id}/download")
def download_report(report_id: str) -> Response:
    daily_report = build_daily_report()
    report = next((item for item in daily_report.reports if item.id == report_id), None)
    if report is None:
        raise HTTPException(status_code=404, detail="未找到报告")

    content = build_daily_report_pdf(daily_report, report)
    return Response(
        content=content,
        media_type="application/pdf",
        headers={
            "Content-Disposition": f'attachment; filename="{report_id}.pdf"',
            "Cache-Control": "private, no-store",
        },
    )
