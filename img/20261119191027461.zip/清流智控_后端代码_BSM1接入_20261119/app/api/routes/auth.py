from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.db import get_db
from app.models import UserRecord
from app.schemas.auth import LoginRequest, LoginResponse, UserResponse
from app.security import create_access_token, verify_password


router = APIRouter()


@router.post("/login", response_model=LoginResponse)
def login(
    payload: LoginRequest,
    session: Session = Depends(get_db),
) -> LoginResponse:
    user = session.scalar(
        select(UserRecord).where(UserRecord.account == payload.account)
    )
    if (
        user is None
        or not user.is_active
        or not verify_password(payload.password, user.password_hash)
    ):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="账号或密码错误",
        )

    token, expires_at = create_access_token(
        account=user.account,
        name=user.name,
        role=user.role,
    )
    return LoginResponse(
        token=token,
        expiresAt=expires_at,
        user=UserResponse(
            name=user.name,
            role=user.role,
        ),
    )
