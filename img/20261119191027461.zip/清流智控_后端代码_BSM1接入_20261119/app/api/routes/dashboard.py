from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.db import get_db
from app.schemas.dashboard import DashboardOverview
from app.services.dashboard_service import build_dashboard_overview
from app.services.snapshot_service import read_snapshot, write_snapshot


router = APIRouter()


@router.get("/overview", response_model=DashboardOverview)
def get_dashboard_overview(
    session: Session = Depends(get_db),
) -> DashboardOverview:
    """返回运行总览页需要的 KPI、风险状态和优化摘要。

    首版从数据库快照读取演示数据，后续可替换为实时聚合查询。
    """

    payload = read_snapshot(session, "dashboard.overview")
    if payload is None:
        overview = build_dashboard_overview()
        write_snapshot(session, "dashboard.overview", overview.model_dump(mode="json"))
        return overview
    return DashboardOverview.model_validate(payload)
