from fastapi import APIRouter, Depends, Query
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.db import get_db
from app.models import (
    MonitoringPointRecord,
    MonitoringSeriesRecord,
    TrendSampleRecord,
)
from app.schemas.monitoring import (
    MonitoringPoint,
    TrendPoint,
    TrendRange,
    TrendSeries,
)


router = APIRouter()


@router.get("/latest", response_model=list[MonitoringPoint])
def get_latest_monitoring(
    session: Session = Depends(get_db),
) -> list[MonitoringPoint]:
    records = session.scalars(
        select(MonitoringPointRecord).order_by(MonitoringPointRecord.sort_order)
    ).all()
    return [
        MonitoringPoint(
            id=record.id,
            name=record.name,
            value=record.value,
            unit=record.unit,
            status=record.status,
            threshold=record.threshold,
            updatedAt=record.updated_at,
        )
        for record in records
    ]


@router.get("/series", response_model=list[TrendSeries])
def get_monitoring_series(
    time_range: TrendRange = Query(default="24h", alias="range"),
    session: Session = Depends(get_db),
) -> list[TrendSeries]:
    definitions = session.scalars(
        select(MonitoringSeriesRecord).order_by(MonitoringSeriesRecord.sort_order)
    ).all()
    samples = session.scalars(
        select(TrendSampleRecord)
        .where(TrendSampleRecord.range_key == time_range)
        .order_by(TrendSampleRecord.series_id, TrendSampleRecord.sequence)
    ).all()

    samples_by_series: dict[str, list[TrendPoint]] = {}
    for sample in samples:
        samples_by_series.setdefault(sample.series_id, []).append(
            TrendPoint(time=sample.time_label, value=sample.value)
        )

    return [
        TrendSeries(
            id=definition.id,
            name=definition.name,
            unit=definition.unit,
            color=definition.color,
            threshold=definition.threshold,
            data=samples_by_series.get(definition.id, []),
        )
        for definition in definitions
    ]
