from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.db import get_db
from app.realtime.websocket import realtime_manager
from app.schemas.alarm import AcknowledgeAlarmRequest, Alarm
from app.services.alarm_service import acknowledge_alarm, list_alarms


router = APIRouter()


@router.get("", response_model=list[Alarm])
def get_alarms(session: Session = Depends(get_db)) -> list[Alarm]:
    return list_alarms(session)


@router.post("/{alarm_id}/acknowledge", response_model=Alarm)
async def acknowledge(
    alarm_id: str,
    payload: AcknowledgeAlarmRequest,
    session: Session = Depends(get_db),
) -> Alarm:
    alarm = acknowledge_alarm(session, alarm_id, payload)
    await realtime_manager.broadcast(
        {
            "type": "alarm.updated",
            "payload": {
                "id": alarm.id,
                "status": alarm.status,
            },
        }
    )
    return alarm
