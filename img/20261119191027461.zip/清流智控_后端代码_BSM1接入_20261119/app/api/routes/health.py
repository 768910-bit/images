from datetime import datetime

from fastapi import APIRouter
from pydantic import BaseModel

from app.db import database_is_healthy


router = APIRouter(tags=["system"])


class HealthResponse(BaseModel):
    status: str
    service: str
    database: str
    serverTime: datetime


@router.get("/health", response_model=HealthResponse)
def health_check() -> HealthResponse:
    return HealthResponse(
        status="ok",
        service="aquaops-backend",
        database="ok" if database_is_healthy() else "unavailable",
        serverTime=datetime.now().astimezone(),
    )
