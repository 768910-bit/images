from fastapi import APIRouter

from app.schemas.simulation import SimulationInput, SimulationResult
from app.services.simulation_service import run_simulation


router = APIRouter()


@router.post("/run", response_model=SimulationResult)
def execute_simulation(payload: SimulationInput) -> SimulationResult:
    return run_simulation(payload)
