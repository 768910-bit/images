from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.data.mock_data import PROCESS_STATUS
from app.db import get_db
from app.schemas.process import ProcessStatus
from app.services.snapshot_service import read_snapshot, write_snapshot


router = APIRouter()


@router.get("/status", response_model=ProcessStatus)
def get_process_status(
    session: Session = Depends(get_db),
) -> ProcessStatus:
    payload = read_snapshot(session, "process.status")
    if payload is None:
        status = PROCESS_STATUS.model_copy(deep=True)
        write_snapshot(session, "process.status", status.model_dump(mode="json"))
        return status
    return ProcessStatus.model_validate(payload)
