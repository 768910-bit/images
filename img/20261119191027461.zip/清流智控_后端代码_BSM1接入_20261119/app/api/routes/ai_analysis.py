from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.db import get_db
from app.schemas.ai_analysis import (
    AIAnalysisRunRequest,
    AIAnalysisRunResponse,
    AIAnalysisTask,
    SavedAnalysisResponse,
)
from app.services.ai_analysis_service import (
    get_analysis_task,
    save_analysis,
    start_analysis,
)


router = APIRouter()


@router.post("/run", response_model=AIAnalysisRunResponse)
def run_analysis(
    payload: AIAnalysisRunRequest,
    session: Session = Depends(get_db),
) -> AIAnalysisRunResponse:
    return AIAnalysisRunResponse(taskId=start_analysis(session, payload.range))


@router.get("/tasks/{task_id}", response_model=AIAnalysisTask)
def get_task(
    task_id: str,
    session: Session = Depends(get_db),
) -> AIAnalysisTask:
    return get_analysis_task(session, task_id)


@router.post("/tasks/{task_id}/save", response_model=SavedAnalysisResponse)
def save_task(
    task_id: str,
    session: Session = Depends(get_db),
) -> SavedAnalysisResponse:
    return save_analysis(session, task_id)
