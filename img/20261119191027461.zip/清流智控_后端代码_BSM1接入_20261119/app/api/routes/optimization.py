from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.data.mock_data import OPTIMIZATION_RECOMMENDATION
from app.db import get_db
from app.schemas.optimization import (
    OptimizationDataSource,
    OptimizationPlansResponse,
    OptimizationRecommendation,
)
from app.services.optimization_service import (
    get_optimization_plans,
    optimization_plans_snapshot_key,
)
from app.services.snapshot_service import read_snapshot, write_snapshot


router = APIRouter()


@router.get("/recommendation", response_model=OptimizationRecommendation)
def get_recommendation(
    session: Session = Depends(get_db),
) -> OptimizationRecommendation:
    payload = read_snapshot(session, "optimization.recommendation")
    if payload is None:
        recommendation = OPTIMIZATION_RECOMMENDATION.model_copy(deep=True)
        write_snapshot(
            session,
            "optimization.recommendation",
            recommendation.model_dump(mode="json"),
        )
        return recommendation
    return OptimizationRecommendation.model_validate(payload)


@router.get("/plans", response_model=OptimizationPlansResponse)
def get_plans(
    source: OptimizationDataSource = Query(default="submittedWorkbook"),
    session: Session = Depends(get_db),
) -> OptimizationPlansResponse:
    snapshot_key = optimization_plans_snapshot_key(source)
    payload = read_snapshot(session, snapshot_key)
    if payload is None:
        plans = get_optimization_plans(source)
        write_snapshot(session, snapshot_key, plans.model_dump(mode="json"))
        return plans
    return OptimizationPlansResponse.model_validate(payload)
