from pydantic import BaseModel

from app.schemas.common import DeviceStatus, RiskLevel


class ProcessMetric(BaseModel):
    label: str
    value: str
    unit: str = ""
    status: RiskLevel


class ProcessDevice(BaseModel):
    name: str
    status: DeviceStatus
    detail: str


class ProcessNode(BaseModel):
    id: str
    name: str
    shortName: str
    status: RiskLevel
    deviceCount: int
    description: str
    metrics: list[ProcessMetric]
    devices: list[ProcessDevice]


class ProcessStatus(BaseModel):
    updatedAt: str
    flow: float
    onlineDevices: int
    deviceTotal: int
    aerationLoad: float
    nodes: list[ProcessNode]
