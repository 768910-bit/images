from typing import Literal

from pydantic import BaseModel

from app.schemas.common import RiskLevel


OptimizationDataSource = Literal[
    "submittedWorkbook",
    "reproducedWithPackagedScript",
]


class BasisItem(BaseModel):
    label: str
    value: str
    detail: str
    tone: Literal["positive", "neutral", "warning"]


class HourlyEnergy(BaseModel):
    time: str
    current: float
    recommended: float


class OptimizationRecommendation(BaseModel):
    updatedAt: str
    currentDO: float
    targetDO: float
    currentAeration: float
    recommendedAeration: float
    energySaving: float
    currentRisk: RiskLevel
    targetRisk: RiskLevel
    confidence: float
    basis: list[BasisItem]
    actions: list[str]
    hourlyEnergy: list[HourlyEnergy]


class OptimizationPlanMetrics(BaseModel):
    ammoniaMean: float
    ammoniaP95: float
    overReferenceHoursPerDay: float
    dailyEnergy: float


class OptimizationCurvePoint(BaseModel):
    time: str
    value: float


class OptimizationPlanCurve(BaseModel):
    id: str
    name: str
    unit: str
    color: str
    data: list[OptimizationCurvePoint]


class OptimizationPlan(BaseModel):
    id: str
    name: str
    source: OptimizationDataSource
    model: str
    operatingCondition: str
    kla5: float
    klaPerDay: list[float] | None = None
    metrics: OptimizationPlanMetrics
    belowReference: bool
    curve: OptimizationPlanCurve | None = None
    curveStatus: Literal["available", "notExported"]
    logFile: str | None = None


class OptimizationSourceInfo(BaseModel):
    source: OptimizationDataSource
    label: str
    sourceFile: str
    influentFile: str | None = None
    modelSnapshot: str | None = None
    runSettingsVerified: bool
    generatedAt: str
    note: str


class OptimizationPlansResponse(BaseModel):
    updatedAt: str
    source: OptimizationDataSource
    availableSources: list[OptimizationSourceInfo]
    selectedId: str
    selectionRule: str
    plans: list[OptimizationPlan]
