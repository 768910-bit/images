from typing import Literal

from pydantic import BaseModel

from app.schemas.common import RiskLevel


TrendRange = Literal["1h", "24h", "7d"]


class MonitoringPoint(BaseModel):
    id: str
    name: str
    value: float
    unit: str
    status: RiskLevel
    threshold: float
    updatedAt: str


class TrendPoint(BaseModel):
    time: str
    value: float


class TrendSeries(BaseModel):
    id: str
    name: str
    unit: str
    color: str
    threshold: float
    data: list[TrendPoint]
