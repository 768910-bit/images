from typing import Literal

from pydantic import BaseModel


class ReportMetric(BaseModel):
    label: str
    value: str
    trend: str


class ReportItem(BaseModel):
    id: str
    title: str
    period: str
    generatedAt: str
    status: Literal["ready", "generating"]
    size: str


class DailyReport(BaseModel):
    id: str
    title: str
    date: str
    summary: list[str]
    metrics: list[ReportMetric]
    reports: list[ReportItem]
    generatedAt: str = ""
