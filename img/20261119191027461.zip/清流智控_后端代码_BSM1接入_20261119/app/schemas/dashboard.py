from pydantic import BaseModel

from app.schemas.common import RiskLevel


class KpiItem(BaseModel):
    key: str
    label: str
    value: float
    unit: str
    decimals: int = 0
    delta: float
    deltaLabel: str
    status: RiskLevel
    sparkline: list[float]


class OptimizationSummary(BaseModel):
    currentDO: float
    targetDO: float
    energySaving: float
    riskChange: str


class DashboardOverview(BaseModel):
    facilityName: str
    updatedAt: str
    riskLevel: RiskLevel
    riskLabel: str
    kpis: list[KpiItem]
    optimization: OptimizationSummary
