from typing import Literal


RiskLevel = Literal["normal", "attention", "warning", "critical"]
DeviceStatus = Literal["running", "standby", "fault"]
AlarmLevel = Literal["critical", "warning", "info"]
AlarmStatus = Literal["open", "acknowledged", "recovered"]
