from pydantic import BaseModel, Field

from app.schemas.common import AlarmLevel, AlarmStatus


class Alarm(BaseModel):
    id: str
    level: AlarmLevel
    title: str
    source: str
    triggeredAt: str
    receivedAt: str
    status: AlarmStatus
    cause: str
    suggestion: str
    expectedAt: str
    owner: str | None = None


class AcknowledgeAlarmRequest(BaseModel):
    owner: str = Field(min_length=1, max_length=50)
    note: str = Field(default="", max_length=500)
