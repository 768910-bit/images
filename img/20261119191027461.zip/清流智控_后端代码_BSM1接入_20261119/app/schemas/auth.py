from datetime import datetime
from typing import Literal

from pydantic import BaseModel, Field


class LoginRequest(BaseModel):
    account: str = Field(min_length=1, max_length=50, examples=["demo"])
    password: str = Field(min_length=1, max_length=128, examples=["demo123"])


class UserResponse(BaseModel):
    name: str
    role: str


class LoginResponse(BaseModel):
    token: str
    tokenType: Literal["bearer"] = "bearer"
    expiresAt: datetime
    user: UserResponse
