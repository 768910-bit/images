from typing import Literal

from pydantic import BaseModel, Field

from app.schemas.common import RiskLevel


class SimulationInput(BaseModel):
    flow: float = Field(ge=0, le=5000)
    cod: float = Field(ge=0, le=2000)
    ammonia: float = Field(ge=0, le=200)
    temperature: float = Field(ge=0, le=50)
    strategy: Literal["baseline", "optimized"] = "optimized"


class SimulationScenarioResult(BaseModel):
    energy: int
    compliance: float
    risk: RiskLevel
    doStability: float


class SimulationTimelinePoint(BaseModel):
    time: str
    currentDO: float
    optimizedDO: float
    currentAmmonia: float
    optimizedAmmonia: float


class SimulationResult(BaseModel):
    runId: str
    createdAt: str
    summary: str
    current: SimulationScenarioResult
    optimized: SimulationScenarioResult
    timeline: list[SimulationTimelinePoint]
