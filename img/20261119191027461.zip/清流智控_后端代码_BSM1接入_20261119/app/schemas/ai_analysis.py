from typing import Literal

from pydantic import BaseModel


AnalysisRange = Literal["24h", "7d", "30d"]
AnalysisStatus = Literal["running", "done", "failed"]
SuggestionKind = Literal["training", "warning"]


class AIAnalysisRunRequest(BaseModel):
    range: AnalysisRange = "24h"


class AIAnalysisRunResponse(BaseModel):
    taskId: str


class AIAnalysisMetric(BaseModel):
    label: str
    value: str


class AIAnalysisSuggestion(BaseModel):
    kind: SuggestionKind
    title: str
    detail: str


class AIAnalysisCurvePoint(BaseModel):
    time: str
    value: float


class AIAnalysisCurve(BaseModel):
    id: str
    name: str
    unit: str
    color: str
    data: list[AIAnalysisCurvePoint]


class AIAnalysisResult(BaseModel):
    score: float
    tip: str
    metrics: list[AIAnalysisMetric]
    suggestions: list[AIAnalysisSuggestion]
    curve: list[AIAnalysisCurve]


class AIAnalysisTask(BaseModel):
    status: AnalysisStatus
    progress: int
    analyzedPoints: int
    result: AIAnalysisResult | None = None


class SavedAnalysisResponse(BaseModel):
    id: str
