import base64
import hashlib
import hmac
import json
import os
import secrets
import time
from dataclasses import dataclass
from datetime import UTC, datetime


_ALGORITHM = "pbkdf2_sha256"
_ITERATIONS = 260_000
_TOKEN_ALGORITHM = "HS256"
_TOKEN_ISSUER = "aquaops"
_DEFAULT_TOKEN_TTL_SECONDS = 8 * 60 * 60
_EPHEMERAL_TOKEN_SECRET = secrets.token_urlsafe(48)


class TokenValidationError(ValueError):
    pass


@dataclass(frozen=True)
class TokenClaims:
    account: str
    name: str
    role: str
    issued_at: int
    expires_at: int


def hash_password(password: str) -> str:
    salt = secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac(
        "sha256",
        password.encode("utf-8"),
        salt.encode("ascii"),
        _ITERATIONS,
    )
    return f"{_ALGORITHM}${_ITERATIONS}${salt}${digest.hex()}"


def verify_password(password: str, encoded: str) -> bool:
    try:
        algorithm, iterations_text, salt, expected = encoded.split("$", 3)
        if algorithm != _ALGORITHM:
            return False
        digest = hashlib.pbkdf2_hmac(
            "sha256",
            password.encode("utf-8"),
            salt.encode("ascii"),
            int(iterations_text),
        )
    except (ValueError, TypeError):
        return False

    return hmac.compare_digest(digest.hex(), expected)


def _token_secret() -> bytes:
    configured = os.getenv("AQUAOPS_SECRET_KEY", "").strip()
    if configured:
        return configured.encode("utf-8")

    environment = os.getenv("AQUAOPS_ENV", "development").strip().lower()
    if environment in {"production", "prod"}:
        raise RuntimeError("生产环境必须配置 AQUAOPS_SECRET_KEY")
    return _EPHEMERAL_TOKEN_SECRET.encode("utf-8")


def _base64url_encode(value: bytes) -> str:
    return base64.urlsafe_b64encode(value).rstrip(b"=").decode("ascii")


def _base64url_decode(value: str) -> bytes:
    padding = "=" * (-len(value) % 4)
    return base64.urlsafe_b64decode(f"{value}{padding}".encode("ascii"))


def _token_ttl_seconds() -> int:
    configured = os.getenv("AQUAOPS_ACCESS_TOKEN_TTL_SECONDS", "").strip()
    if not configured:
        return _DEFAULT_TOKEN_TTL_SECONDS
    try:
        ttl = int(configured)
    except ValueError as exc:
        raise RuntimeError("AQUAOPS_ACCESS_TOKEN_TTL_SECONDS 必须是整数") from exc
    if ttl <= 0:
        raise RuntimeError("AQUAOPS_ACCESS_TOKEN_TTL_SECONDS 必须大于 0")
    return ttl


def create_access_token(
    *,
    account: str,
    name: str,
    role: str,
    ttl_seconds: int | None = None,
) -> tuple[str, datetime]:
    issued_at = int(time.time())
    expires_at = issued_at + (ttl_seconds or _token_ttl_seconds())
    header = {"alg": _TOKEN_ALGORITHM, "typ": "JWT"}
    payload = {
        "sub": account,
        "name": name,
        "role": role,
        "iat": issued_at,
        "exp": expires_at,
        "iss": _TOKEN_ISSUER,
    }
    encoded_header = _base64url_encode(
        json.dumps(header, separators=(",", ":"), ensure_ascii=True).encode("utf-8")
    )
    encoded_payload = _base64url_encode(
        json.dumps(payload, separators=(",", ":"), ensure_ascii=True).encode("utf-8")
    )
    signing_input = f"{encoded_header}.{encoded_payload}".encode("ascii")
    signature = hmac.new(_token_secret(), signing_input, hashlib.sha256).digest()
    token = f"{encoded_header}.{encoded_payload}.{_base64url_encode(signature)}"
    return token, datetime.fromtimestamp(expires_at, UTC)


def decode_access_token(token: str) -> TokenClaims:
    try:
        encoded_header, encoded_payload, encoded_signature = token.split(".", 2)
    except ValueError as exc:
        raise TokenValidationError("访问令牌格式无效") from exc

    signing_input = f"{encoded_header}.{encoded_payload}".encode("ascii")
    expected_signature = hmac.new(
        _token_secret(),
        signing_input,
        hashlib.sha256,
    ).digest()
    try:
        supplied_signature = _base64url_decode(encoded_signature)
    except (ValueError, UnicodeEncodeError) as exc:
        raise TokenValidationError("访问令牌签名无效") from exc
    if not hmac.compare_digest(supplied_signature, expected_signature):
        raise TokenValidationError("访问令牌签名无效")

    try:
        header = json.loads(_base64url_decode(encoded_header))
        payload = json.loads(_base64url_decode(encoded_payload))
    except (ValueError, TypeError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise TokenValidationError("访问令牌内容无效") from exc

    if header.get("alg") != _TOKEN_ALGORITHM or header.get("typ") != "JWT":
        raise TokenValidationError("访问令牌算法无效")
    if payload.get("iss") != _TOKEN_ISSUER:
        raise TokenValidationError("访问令牌签发方无效")

    account = payload.get("sub")
    name = payload.get("name")
    role = payload.get("role")
    issued_at = payload.get("iat")
    expires_at = payload.get("exp")
    if not all(isinstance(value, str) and value for value in (account, name, role)):
        raise TokenValidationError("访问令牌用户信息无效")
    if not isinstance(issued_at, int) or not isinstance(expires_at, int):
        raise TokenValidationError("访问令牌有效期无效")
    if expires_at <= int(time.time()):
        raise TokenValidationError("访问令牌已过期")

    return TokenClaims(
        account=account,
        name=name,
        role=role,
        issued_at=issued_at,
        expires_at=expires_at,
    )
