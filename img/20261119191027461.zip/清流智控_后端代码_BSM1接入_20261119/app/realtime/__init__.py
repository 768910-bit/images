"""Realtime transport for measurements and alarm updates."""
