import asyncio
import math
from datetime import datetime
from typing import Any

from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from app.api.deps import resolve_user_from_token
from app.db import SessionLocal


router = APIRouter()


class RealtimeConnectionManager:
    def __init__(self) -> None:
        self._connections: set[WebSocket] = set()

    async def register(self, websocket: WebSocket) -> None:
        self._connections.add(websocket)
        await websocket.send_json(
            {
                "type": "connection.state",
                "payload": {
                    "state": "connected",
                    "latencyMs": 12,
                },
            }
        )

    def disconnect(self, websocket: WebSocket) -> None:
        self._connections.discard(websocket)

    async def broadcast(self, event: dict[str, Any]) -> None:
        disconnected: list[WebSocket] = []
        for connection in tuple(self._connections):
            try:
                await connection.send_json(event)
            except Exception:
                disconnected.append(connection)

        for connection in disconnected:
            self.disconnect(connection)


realtime_manager = RealtimeConnectionManager()


async def _reject_connection(websocket: WebSocket) -> None:
    await websocket.send_json(
        {
            "type": "connection.error",
            "payload": {
                "code": "unauthorized",
                "message": "访问令牌无效或已过期",
            },
        }
    )
    await websocket.close(code=1008)


@router.websocket("/ws/realtime")
async def realtime_channel(websocket: WebSocket) -> None:
    await websocket.accept()
    try:
        auth_message = await asyncio.wait_for(
            websocket.receive_json(),
            timeout=5,
        )
    except (asyncio.TimeoutError, WebSocketDisconnect, ValueError):
        await _reject_connection(websocket)
        return

    auth_payload = auth_message.get("payload", {})
    token = auth_payload.get("token", "").strip() if isinstance(auth_payload, dict) else ""
    if auth_message.get("type") != "auth" or not token:
        await _reject_connection(websocket)
        return
    with SessionLocal() as session:
        user = resolve_user_from_token(session, token)
    if user is None:
        await _reject_connection(websocket)
        return

    await realtime_manager.register(websocket)

    tick = 0
    try:
        while True:
            await asyncio.sleep(3)
            do_value = round(2.35 + math.sin(tick / 3) * 0.08, 2)
            await websocket.send_json(
                {
                    "type": "measurement.updated",
                    "payload": {
                        "pointId": "do",
                        "value": do_value,
                        "unit": "mg/L",
                        "timestamp": datetime.now().astimezone().isoformat(),
                        "quality": "good",
                    },
                }
            )
            tick += 1
    except WebSocketDisconnect:
        pass
    finally:
        realtime_manager.disconnect(websocket)
