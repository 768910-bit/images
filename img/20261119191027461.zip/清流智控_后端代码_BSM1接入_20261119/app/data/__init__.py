"""Demo data used while the real database and simulator are not connected."""
