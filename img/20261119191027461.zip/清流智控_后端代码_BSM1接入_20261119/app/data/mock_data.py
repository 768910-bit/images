from app.schemas.alarm import Alarm
from app.schemas.monitoring import MonitoringPoint
from app.schemas.optimization import OptimizationRecommendation
from app.schemas.process import ProcessStatus
from app.schemas.report import DailyReport


PROCESS_STATUS = ProcessStatus.model_validate(
    {
        "updatedAt": "14:32:08",
        "flow": 1246,
        "onlineDevices": 21,
        "deviceTotal": 24,
        "aerationLoad": 58,
        "nodes": [
            {
                "id": "inlet",
                "name": "进水泵房",
                "shortName": "进水",
                "status": "attention",
                "deviceCount": 4,
                "description": "提升并分配厂区进水，当前流量偏高。",
                "metrics": [
                    {"label": "流量", "value": "1,246", "unit": "m³/h", "status": "attention"},
                    {"label": "液位", "value": "3.82", "unit": "m", "status": "normal"},
                ],
                "devices": [
                    {"name": "进水泵 P-01", "status": "running", "detail": "78% 负荷"},
                    {"name": "进水泵 P-02", "status": "standby", "detail": "备机"},
                ],
            },
            {
                "id": "grit",
                "name": "粗细格栅",
                "shortName": "格栅",
                "status": "normal",
                "deviceCount": 2,
                "description": "拦截大颗粒悬浮物，保护后续生化系统。",
                "metrics": [
                    {"label": "栅前液位", "value": "1.12", "unit": "m", "status": "normal"},
                    {"label": "运行频率", "value": "46", "unit": "Hz", "status": "normal"},
                ],
                "devices": [
                    {"name": "细格栅 G-01", "status": "running", "detail": "连续运行"},
                    {"name": "螺旋输送机", "status": "running", "detail": "联动运行"},
                ],
            },
            {
                "id": "anaerobic",
                "name": "厌氧池",
                "shortName": "厌氧",
                "status": "normal",
                "deviceCount": 3,
                "description": "释放磷并完成水解酸化，为缺氧段提供碳源。",
                "metrics": [
                    {"label": "溶解氧", "value": "0.16", "unit": "mg/L", "status": "normal"},
                    {"label": "氧化还原电位", "value": "-168", "unit": "mV", "status": "normal"},
                ],
                "devices": [
                    {"name": "搅拌器 A-01", "status": "running", "detail": "62% 频率"},
                    {"name": "搅拌器 A-02", "status": "running", "detail": "62% 频率"},
                ],
            },
            {
                "id": "anoxic",
                "name": "缺氧池",
                "shortName": "缺氧",
                "status": "normal",
                "deviceCount": 3,
                "description": "反硝化脱氮，当前碳氮比处于合理区间。",
                "metrics": [
                    {"label": "溶解氧", "value": "0.42", "unit": "mg/L", "status": "normal"},
                    {"label": "硝酸盐氮", "value": "5.8", "unit": "mg/L", "status": "normal"},
                ],
                "devices": [
                    {"name": "搅拌器 D-01", "status": "running", "detail": "58% 频率"},
                    {"name": "回流泵 R-01", "status": "running", "detail": "210 m³/h"},
                ],
            },
            {
                "id": "aerobic",
                "name": "好氧池",
                "shortName": "好氧",
                "status": "warning",
                "deviceCount": 6,
                "description": "进水氨氮上升，溶解氧轻微不足，建议提高曝气强度。",
                "metrics": [
                    {"label": "溶解氧", "value": "2.35", "unit": "mg/L", "status": "warning"},
                    {"label": "氨氮", "value": "3.6", "unit": "mg/L", "status": "attention"},
                    {"label": "污泥浓度", "value": "3,260", "unit": "mg/L", "status": "normal"},
                ],
                "devices": [
                    {"name": "鼓风机 B-01", "status": "running", "detail": "58% 负荷"},
                    {"name": "鼓风机 B-02", "status": "standby", "detail": "备机"},
                    {"name": "曝气盘组 E-03", "status": "running", "detail": "压差正常"},
                    {"name": "在线 DO 仪 D-04", "status": "running", "detail": "信号正常"},
                ],
            },
            {
                "id": "settler",
                "name": "二沉池",
                "shortName": "二沉",
                "status": "normal",
                "deviceCount": 4,
                "description": "泥水分离稳定，出水澄清度良好。",
                "metrics": [
                    {"label": "出水浊度", "value": "2.8", "unit": "NTU", "status": "normal"},
                    {"label": "污泥界面", "value": "1.46", "unit": "m", "status": "normal"},
                ],
                "devices": [
                    {"name": "刮泥机 S-01", "status": "running", "detail": "自动运行"},
                    {"name": "污泥回流泵 R-02", "status": "running", "detail": "86 m³/h"},
                ],
            },
            {
                "id": "disinfection",
                "name": "消毒出水",
                "shortName": "出水",
                "status": "normal",
                "deviceCount": 2,
                "description": "消毒后达标排放，近 24 小时无超标。",
                "metrics": [
                    {"label": "出水 COD", "value": "26", "unit": "mg/L", "status": "normal"},
                    {"label": "出水氨氮", "value": "0.82", "unit": "mg/L", "status": "normal"},
                ],
                "devices": [
                    {"name": "紫外消毒器 U-01", "status": "running", "detail": "剂量正常"},
                    {"name": "排放口在线仪", "status": "running", "detail": "数据有效"},
                ],
            },
        ],
    }
)


MONITORING_POINTS = [
    MonitoringPoint.model_validate(item)
    for item in [
        {
            "id": "cod",
            "name": "进水 COD",
            "value": 286,
            "unit": "mg/L",
            "status": "attention",
            "threshold": 300,
            "updatedAt": "14:32:08",
        },
        {
            "id": "ammonia",
            "name": "进水氨氮",
            "value": 18.6,
            "unit": "mg/L",
            "status": "warning",
            "threshold": 18,
            "updatedAt": "14:32:08",
        },
        {
            "id": "do",
            "name": "好氧池 DO",
            "value": 2.35,
            "unit": "mg/L",
            "status": "warning",
            "threshold": 2.5,
            "updatedAt": "14:32:06",
        },
        {
            "id": "ph",
            "name": "进水 pH",
            "value": 7.18,
            "unit": "",
            "status": "normal",
            "threshold": 9,
            "updatedAt": "14:32:04",
        },
        {
            "id": "flow",
            "name": "瞬时流量",
            "value": 1246,
            "unit": "m³/h",
            "status": "attention",
            "threshold": 1400,
            "updatedAt": "14:32:08",
        },
        {
            "id": "temperature",
            "name": "水温",
            "value": 21.4,
            "unit": "°C",
            "status": "normal",
            "threshold": 30,
            "updatedAt": "14:31:58",
        },
    ]
]


ALARMS = [
    Alarm.model_validate(item)
    for item in [
        {
            "id": "AL-20261107-018",
            "level": "critical",
            "title": "出水氨氮存在超标风险",
            "source": "好氧池 / 在线氨氮仪",
            "triggeredAt": "14:28:16",
            "receivedAt": "3 分钟前",
            "status": "open",
            "cause": "进水氨氮快速上升，好氧池溶解氧低于优化目标。",
            "suggestion": "将鼓风机 B-01 负荷由 58% 提升至 68%，30 分钟后复核溶解氧。",
            "expectedAt": "预计 42 分钟后可能超过 5 mg/L",
            "owner": None,
        },
        {
            "id": "AL-20261107-017",
            "level": "warning",
            "title": "好氧池溶解氧偏低",
            "source": "好氧池 / DO-04",
            "triggeredAt": "14:22:05",
            "receivedAt": "9 分钟前",
            "status": "open",
            "cause": "进水负荷上升，当前曝气强度未能及时匹配。",
            "suggestion": "执行曝气优化建议，并观察 20 分钟内的 DO 响应。",
            "expectedAt": "持续低于 2.5 mg/L",
            "owner": None,
        },
        {
            "id": "AL-20261107-016",
            "level": "warning",
            "title": "进水流量波动超过 8%",
            "source": "进水泵房 / FT-01",
            "triggeredAt": "13:56:42",
            "receivedAt": "36 分钟前",
            "status": "acknowledged",
            "cause": "上游管网来水短时集中，进水流量达到 1,246 m³/h。",
            "suggestion": "保持进水泵两用一备，关注格栅前后液位差。",
            "expectedAt": "当前仍在波动",
            "owner": "李工",
        },
        {
            "id": "AL-20261107-015",
            "level": "info",
            "title": "今日节能目标完成 82%",
            "source": "曝气优化 / 能耗分析",
            "triggeredAt": "13:30:00",
            "receivedAt": "1 小时前",
            "status": "recovered",
            "cause": "上午执行两条错峰曝气建议，单位水量电耗下降。",
            "suggestion": "继续观察晚高峰进水冲击。",
            "expectedAt": "已恢复正常",
            "owner": "系统",
        },
        {
            "id": "AL-20261107-014",
            "level": "info",
            "title": "传感器数据质量恢复",
            "source": "二沉池 / NTU-02",
            "triggeredAt": "12:48:20",
            "receivedAt": "1 小时前",
            "status": "recovered",
            "cause": "探头清洗后信号恢复稳定。",
            "suggestion": "下次维护计划已自动顺延至 2026-12-07。",
            "expectedAt": "已恢复正常",
            "owner": "王工",
        },
    ]
]


OPTIMIZATION_RECOMMENDATION = OptimizationRecommendation.model_validate(
    {
        "updatedAt": "14:30:00",
        "currentDO": 2.35,
        "targetDO": 2.8,
        "currentAeration": 58,
        "recommendedAeration": 68,
        "energySaving": 8.6,
        "currentRisk": "warning",
        "targetRisk": "normal",
        "confidence": 91,
        "basis": [
            {
                "label": "进水负荷",
                "value": "+12.4%",
                "detail": "COD 较 1 小时前上升，需提高供氧余量。",
                "tone": "warning",
            },
            {
                "label": "DO 响应",
                "value": "18 min",
                "detail": "根据鼓风机历史响应曲线，预计调节后 18 分钟达标。",
                "tone": "neutral",
            },
            {
                "label": "预计电耗",
                "value": "-0.038 kWh/m³",
                "detail": "在控制出水风险的前提下，仍有 8.6% 的节能空间。",
                "tone": "positive",
            },
        ],
        "actions": [
            "将鼓风机 B-01 负荷从 58% 调整至 68%",
            "20 分钟后复核好氧池末端 DO",
            "若 40 分钟后氨氮仍高于 4.5 mg/L，启动备机 B-02",
        ],
        "hourlyEnergy": [
            {"time": "08:00", "current": 228, "recommended": 214},
            {"time": "09:00", "current": 241, "recommended": 225},
            {"time": "10:00", "current": 256, "recommended": 238},
            {"time": "11:00", "current": 263, "recommended": 247},
            {"time": "12:00", "current": 248, "recommended": 231},
            {"time": "13:00", "current": 252, "recommended": 236},
            {"time": "14:00", "current": 258, "recommended": 242},
        ],
    }
)


DAILY_REPORT = DailyReport.model_validate(
    {
        "id": "RPT-20261107",
        "title": "江北第二污水处理厂 · 运行日报",
        "date": "2026 年 11 月 7 日",
        "summary": [
            "全厂累计处理水量 28,614 m³，平均进水流量 1,192 m³/h。",
            "当日出现 1 次进水氨氮冲击，已通过提高曝气强度保持在达标区间。",
            "曝气单元单位水量电耗较基准策略下降 8.6%，预计节约 412 kWh。",
        ],
        "metrics": [
            {"label": "处理水量", "value": "28,614 m³", "trend": "+2.8%"},
            {"label": "出水达标率", "value": "99.2%", "trend": "+0.3%"},
            {"label": "单位电耗", "value": "0.294 kWh/m³", "trend": "-8.6%"},
            {"label": "告警处置", "value": "4 / 5", "trend": "80%"},
        ],
        "reports": [
            {
                "id": "RPT-20261107",
                "title": "运行日报（11 月 7 日）",
                "period": "2026-11-07",
                "generatedAt": "今天 14:00",
                "status": "ready",
                "size": "1.8 MB",
            },
            {
                "id": "RPT-20261106",
                "title": "运行日报（11 月 6 日）",
                "period": "2026-11-06",
                "generatedAt": "昨天 18:10",
                "status": "ready",
                "size": "2.1 MB",
            },
            {
                "id": "RPT-20261105",
                "title": "运行日报（11 月 5 日）",
                "period": "2026-11-05",
                "generatedAt": "11 月 5 日 18:06",
                "status": "ready",
                "size": "1.9 MB",
            },
        ],
    }
)
