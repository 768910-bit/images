from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.data.mock_data import (
    ALARMS,
    MONITORING_POINTS,
    OPTIMIZATION_RECOMMENDATION,
    PROCESS_STATUS,
)
from app.models import (
    AlarmRecord,
    BusinessSnapshot,
    MonitoringPointRecord,
    MonitoringSeriesRecord,
    TrendSampleRecord,
    UserRecord,
)
from app.schemas.optimization import OptimizationDataSource
from app.security import hash_password
from app.services.dashboard_service import build_dashboard_overview
from app.services.optimization_service import (
    get_optimization_plans,
    optimization_plans_snapshot_key,
)
from app.services.trend_service import create_trend_series


def _is_empty(session: Session, model: type[object]) -> bool:
    count = session.scalar(select(func.count()).select_from(model))
    return not count


def _seed_monitoring(session: Session) -> None:
    if _is_empty(session, MonitoringPointRecord):
        for index, point in enumerate(MONITORING_POINTS):
            session.add(
                MonitoringPointRecord(
                    id=point.id,
                    name=point.name,
                    value=point.value,
                    unit=point.unit,
                    status=point.status,
                    threshold=point.threshold,
                    updated_at=point.updatedAt,
                    sort_order=index,
                )
            )

    if not _is_empty(session, MonitoringSeriesRecord):
        return

    definitions = create_trend_series("24h")
    for index, series in enumerate(definitions):
        session.add(
            MonitoringSeriesRecord(
                id=series.id,
                name=series.name,
                unit=series.unit,
                color=series.color,
                threshold=series.threshold,
                sort_order=index,
            )
        )

    for range_key in ("1h", "24h", "7d"):
        for series in create_trend_series(range_key):
            for sequence, point in enumerate(series.data):
                session.add(
                    TrendSampleRecord(
                        series_id=series.id,
                        range_key=range_key,
                        sequence=sequence,
                        time_label=point.time,
                        value=point.value,
                    )
                )


def _seed_alarms(session: Session) -> None:
    if not _is_empty(session, AlarmRecord):
        return

    for alarm in ALARMS:
        session.add(
            AlarmRecord(
                id=alarm.id,
                level=alarm.level,
                title=alarm.title,
                source=alarm.source,
                triggered_at=alarm.triggeredAt,
                received_at=alarm.receivedAt,
                status=alarm.status,
                cause=alarm.cause,
                suggestion=alarm.suggestion,
                expected_at=alarm.expectedAt,
                owner=alarm.owner,
            )
        )


def _seed_users(session: Session) -> None:
    demo = session.scalar(select(UserRecord).where(UserRecord.account == "demo"))
    if demo is None:
        session.add(
            UserRecord(
                account="demo",
                password_hash=hash_password("demo123"),
                name="演示用户",
                role="运行值班",
            )
        )


def _seed_snapshots(session: Session) -> None:
    sources: tuple[OptimizationDataSource, ...] = (
        "submittedWorkbook",
        "reproducedWithPackagedScript",
    )
    snapshots = {
        "dashboard.overview": build_dashboard_overview().model_dump(mode="json"),
        "process.status": PROCESS_STATUS.model_dump(mode="json"),
        "optimization.recommendation": OPTIMIZATION_RECOMMENDATION.model_dump(
            mode="json"
        ),
    }
    snapshots.update(
        {
            optimization_plans_snapshot_key(source): get_optimization_plans(
                source
            ).model_dump(mode="json")
            for source in sources
        }
    )

    for key, payload in snapshots.items():
        if session.get(BusinessSnapshot, key) is None:
            session.add(BusinessSnapshot(key=key, payload=payload))


def seed_database(session: Session) -> None:
    _seed_monitoring(session)
    _seed_alarms(session)
    _seed_users(session)
    _seed_snapshots(session)
    session.commit()
