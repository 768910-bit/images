from datetime import datetime

from fastapi.testclient import TestClient
from starlette.websockets import WebSocketDisconnect
from sqlalchemy import func, select

from app.db import SessionLocal, init_db
from app.main import app
from app.models import (
    AlarmRecord,
    MonitoringPointRecord,
    MonitoringSeriesRecord,
    TrendSampleRecord,
    UserRecord,
)

public_client = TestClient(app)
login_response = public_client.post(
    "/api/auth/login",
    json={
        "account": "demo",
        "password": "demo123",
    },
)
assert login_response.status_code == 200
access_token = login_response.json()["token"]
client = TestClient(
    app,
    headers={"Authorization": f"Bearer {access_token}"},
)


def test_health_check() -> None:
    response = client.get("/api/health")

    assert response.status_code == 200
    assert response.json()["status"] == "ok"
    assert response.json()["service"] == "aquaops-backend"
    assert response.json()["database"] == "ok"


def test_database_seed_is_idempotent() -> None:
    models = (
        MonitoringPointRecord,
        MonitoringSeriesRecord,
        TrendSampleRecord,
        AlarmRecord,
        UserRecord,
    )

    with SessionLocal() as session:
        before = {
            model.__tablename__: session.scalar(
                select(func.count()).select_from(model)
            )
            for model in models
        }

    init_db()

    with SessionLocal() as session:
        after = {
            model.__tablename__: session.scalar(
                select(func.count()).select_from(model)
            )
            for model in models
        }

    assert after == before
    assert after["monitoring_points"] == 6
    assert after["monitoring_series"] == 6
    assert after["trend_samples"] == 318
    assert after["alarms"] == 5


def test_login_success() -> None:
    response = public_client.post(
        "/api/auth/login",
        json={
            "account": "demo",
            "password": "demo123",
        },
    )

    assert response.status_code == 200
    assert response.json()["token"] != "mock-access-token"
    assert response.json()["tokenType"] == "bearer"
    assert response.json()["expiresAt"]
    assert response.json()["user"]["name"] == "演示用户"


def test_login_rejects_wrong_password() -> None:
    response = public_client.post(
        "/api/auth/login",
        json={
            "account": "demo",
            "password": "wrong-password",
        },
    )

    assert response.status_code == 401
    assert response.json()["detail"] == "账号或密码错误"


def test_protected_route_requires_token() -> None:
    response = public_client.get("/api/dashboard/overview")

    assert response.status_code == 401
    assert response.json()["detail"] == "缺少访问令牌"
    assert response.headers["www-authenticate"] == "Bearer"


def test_protected_route_rejects_tampered_token() -> None:
    response = public_client.get(
        "/api/dashboard/overview",
        headers={"Authorization": f"Bearer {access_token}tampered"},
    )

    assert response.status_code == 401
    assert response.json()["detail"] == "访问令牌无效或已过期"


def test_dashboard_overview() -> None:
    response = client.get("/api/dashboard/overview")

    assert response.status_code == 200
    data = response.json()
    assert data["facilityName"] == "江北第二污水处理厂"
    assert len(data["kpis"]) == 8
    assert data["kpis"][2]["key"] == "ammonia"
    assert data["optimization"]["targetDO"] == 2.8


def test_process_status() -> None:
    response = client.get("/api/process/status")

    assert response.status_code == 200
    data = response.json()
    assert len(data["nodes"]) == 7
    assert data["flow"] == 1246
    assert data["onlineDevices"] == 21
    assert data["deviceTotal"] == 24
    assert data["aerationLoad"] == 58
    assert data["nodes"][4]["id"] == "aerobic"
    assert data["nodes"][4]["status"] == "warning"


def test_monitoring_latest() -> None:
    response = client.get("/api/monitoring/latest")

    assert response.status_code == 200
    data = response.json()
    assert len(data) == 6
    assert data[1]["id"] == "ammonia"
    assert data[1]["threshold"] == 18


def test_monitoring_series() -> None:
    response = client.get("/api/monitoring/series", params={"range": "24h"})

    assert response.status_code == 200
    data = response.json()
    assert len(data) == 6
    assert len(data[0]["data"]) == 25
    assert data[0]["unit"] == "mg/L"


def test_optimization_recommendation() -> None:
    response = client.get("/api/optimization/recommendation")

    assert response.status_code == 200
    data = response.json()
    assert data["recommendedAeration"] == 68
    assert data["confidence"] == 91
    assert len(data["basis"]) == 3


def test_optimization_plans() -> None:
    response = client.get("/api/optimization/plans")

    assert response.status_code == 200
    data = response.json()
    assert data["source"] == "submittedWorkbook"
    assert data["selectedId"] == "submitted-kla-180"
    assert [plan["id"] for plan in data["plans"]] == [
        "submitted-kla-84",
        "submitted-kla-180",
        "submitted-kla-185",
        "submitted-kla-195",
    ]
    assert len(data["availableSources"]) == 2

    for plan in data["plans"]:
        assert plan["source"] == "submittedWorkbook"
        assert plan["model"] == "原表转录"
        assert plan["klaPerDay"] is None
        assert plan["curve"] is None
        assert plan["curveStatus"] == "notExported"
        assert plan["metrics"]["overReferenceHoursPerDay"] > 0

    submitted_84 = data["plans"][0]["metrics"]
    submitted_180 = data["plans"][1]["metrics"]
    assert round(submitted_180["dailyEnergy"] - submitted_84["dailyEnergy"], 2) == 63.7
    assert round(
        submitted_180["overReferenceHoursPerDay"]
        - submitted_84["overReferenceHoursPerDay"],
        2,
    ) == -13.67

    reproduced = client.get(
        "/api/optimization/plans",
        params={"source": "reproducedWithPackagedScript"},
    )
    assert reproduced.status_code == 200
    reproduced_data = reproduced.json()
    assert reproduced_data["source"] == "reproducedWithPackagedScript"
    assert reproduced_data["selectedId"] == "kla-185"
    assert reproduced_data["plans"][2]["belowReference"] is True
    assert reproduced_data["plans"][1]["belowReference"] is False
    assert reproduced_data["plans"][2]["klaPerDay"] == [0, 0, 240, 240, 185]
    assert reproduced_data["plans"][2]["logFile"] == "kla_185.log"
    assert reproduced_data["plans"][2]["curve"] is None
    assert set(reproduced_data["plans"][2]["metrics"]) == {
        "ammoniaMean",
        "ammoniaP95",
        "overReferenceHoursPerDay",
        "dailyEnergy",
    }

    invalid = client.get(
        "/api/optimization/plans",
        params={"source": "unknown"},
    )
    assert invalid.status_code == 422


def test_alarm_acknowledge_updates_state() -> None:
    before = client.get("/api/alarms")
    assert before.status_code == 200

    target = next(item for item in before.json() if item["status"] == "open")
    response = client.post(
        f"/api/alarms/{target['id']}/acknowledge",
        json={
            "owner": "张工",
            "note": "已确认，开始执行建议措施",
        },
    )

    assert response.status_code == 200
    assert response.json()["status"] == "acknowledged"
    assert response.json()["owner"] == "张工"

    after = client.get("/api/alarms")
    updated = next(item for item in after.json() if item["id"] == target["id"])
    assert updated["status"] == "acknowledged"


def test_simulation_run() -> None:
    response = client.post(
        "/api/simulation/run",
        json={
            "flow": 1420,
            "cod": 320,
            "ammonia": 22,
            "temperature": 21.4,
            "strategy": "optimized",
        },
    )

    assert response.status_code == 200
    data = response.json()
    assert data["runId"].startswith("SIM-")
    assert len(data["timeline"]) == 7
    assert data["optimized"]["energy"] < data["current"]["energy"]


def test_daily_report_and_download() -> None:
    response = client.get("/api/reports/daily")
    assert response.status_code == 200
    data = response.json()
    assert len(data["reports"]) == 3

    today = datetime.now().astimezone()
    assert data["id"] == f"RPT-{today:%Y%m%d}"
    assert data["date"] == f"{today.year} 年 {today.month} 月 {today.day} 日"
    assert data["generatedAt"].endswith(("+08:00", "+00:00", "Z"))

    download = client.get(f"/api/reports/{data['id']}/download")
    assert download.status_code == 200
    assert "attachment" in download.headers["content-disposition"]
    assert ".pdf" in download.headers["content-disposition"]
    assert download.headers["content-type"] == "application/pdf"
    assert download.content.startswith(b"%PDF-")


def test_ai_analysis_lifecycle() -> None:
    run = client.post("/api/ai-analysis/run", json={"range": "24h"})
    assert run.status_code == 200
    task_id = run.json()["taskId"]
    assert task_id.startswith("AI-")

    first = client.get(f"/api/ai-analysis/tasks/{task_id}")
    assert first.status_code == 200
    assert first.json()["status"] == "running"
    assert first.json()["progress"] < 100

    task = first.json()
    for _ in range(2):
        response = client.get(f"/api/ai-analysis/tasks/{task_id}")
        assert response.status_code == 200
        task = response.json()

    assert task["status"] == "done"
    assert task["progress"] == 100
    assert task["analyzedPoints"] == 827
    assert task["result"]["score"] == 86
    assert len(task["result"]["suggestions"]) == 2
    assert len(task["result"]["curve"]) == 2

    saved = client.post(f"/api/ai-analysis/tasks/{task_id}/save")
    assert saved.status_code == 200
    assert saved.json()["id"].startswith("AIS-")

    saved_again = client.post(f"/api/ai-analysis/tasks/{task_id}/save")
    assert saved_again.json()["id"] == saved.json()["id"]


def test_realtime_websocket_connects() -> None:
    with client.websocket_connect("/ws/realtime") as websocket:
        websocket.send_json(
            {
                "type": "auth",
                "payload": {"token": access_token},
            }
        )
        message = websocket.receive_json()

    assert message["type"] == "connection.state"
    assert message["payload"]["state"] == "connected"


def test_realtime_pushes_alarm_update() -> None:
    target = client.get("/api/alarms").json()[0]

    with client.websocket_connect("/ws/realtime") as websocket:
        websocket.send_json(
            {
                "type": "auth",
                "payload": {"token": access_token},
            }
        )
        websocket.receive_json()
        response = client.post(
            f"/api/alarms/{target['id']}/acknowledge",
            json={
                "owner": "张工",
                "note": "已确认",
            },
        )
        message = websocket.receive_json()

    assert response.status_code == 200
    assert message == {
        "type": "alarm.updated",
        "payload": {
            "id": target["id"],
            "status": "acknowledged",
        },
    }


def test_realtime_websocket_requires_token() -> None:
    with public_client.websocket_connect("/ws/realtime") as websocket:
        websocket.send_json(
            {
                "type": "auth",
                "payload": {},
            }
        )
        message = websocket.receive_json()
        assert message["type"] == "connection.error"
        assert message["payload"]["code"] == "unauthorized"
        try:
            websocket.receive_json()
        except WebSocketDisconnect as exc:
            assert exc.code == 1008
        else:
            raise AssertionError("WebSocket should close after an auth error")
