import os
import tempfile
import uuid
from pathlib import Path


_TEST_DB_PATH = Path(tempfile.gettempdir()) / f"aquaops-test-{uuid.uuid4().hex}.db"
os.environ["DATABASE_URL"] = f"sqlite:///{_TEST_DB_PATH.as_posix()}"
os.environ["AQUAOPS_AUTO_SEED"] = "true"
os.environ["AQUAOPS_SECRET_KEY"] = "test-only-signing-key"


def pytest_sessionfinish(session: object, exitstatus: int) -> None:
    del session, exitstatus
    try:
        from app.db import engine

        engine.dispose()
    finally:
        _TEST_DB_PATH.unlink(missing_ok=True)
