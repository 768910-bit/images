# 清流智控后端交接说明

更新日期：2026-11-19

本包包含 BSM1 曝气方案两套结果来源、现有 FastAPI 后端代码、接口文档、测试和 Windows 四档复跑证据。

## 环境

- Python 3.12
- 建议使用独立虚拟环境

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

## 启动

```powershell
.\.venv\Scripts\python.exe run.py
```

默认接口地址：

```text
http://127.0.0.1:9000
```

接口文档：

```text
http://127.0.0.1:9000/docs
```

测试账号：

```text
账号：demo
密码：demo123
```

## 测试

```powershell
.\.venv\Scripts\python.exe -m pytest -q
```

当前测试结果：19 项通过。

## BSM1 方案接口

```http
GET /api/optimization/plans?source=submittedWorkbook
GET /api/optimization/plans?source=reproducedWithPackagedScript
```

两套来源严格分开：

- `submittedWorkbook`：学姐提交原表，推荐 `submitted-kla-180`
- `reproducedWithPackagedScript`：Windows 复跑结果，推荐 `kla-185`

接口字段：

- `source`
- `klaPerDay`
- `metrics.ammoniaMean`
- `metrics.ammoniaP95`
- `metrics.overReferenceHoursPerDay`
- `metrics.dailyEnergy`
- `belowReference`
- `selectedId`
- `curve`

当前所有 `curve` 均为 `null`，`curveStatus` 为 `notExported`。原表来源只记录了第 5 池 KLa，因此 `klaPerDay` 为 `null`。

## 数据文件

```text
app/data/bsm1_handoff/
├─ submitted_plans.json
├─ reproduced_plans.json
└─ comparison.json
```

## Windows 复跑证据

证据位于：

```text
validation/windows_20261118/
```

包含：

- Windows 环境信息
- 安装与控制台日志
- 依赖版本
- 四份脚本日志
- 四档结果
- 与 Linux 原验证记录的逐项核对结果
- 数据与脚本校验值

结论：四档指标与既有验证记录一致，日志文本内容一致，仅换行符不同。

## 当前未完成

- `POST` 仿真任务创建
- `GET` 仿真任务状态与错误日志
- 从同一次运行导出时间、氨氮和流量曲线

## 主要文件

- `app/schemas/optimization.py`：方案接口数据模型
- `app/services/optimization_service.py`：两套来源读取与映射
- `app/api/routes/optimization.py`：接口路由
- `tests/test_api.py`：接口回归测试
- `docs/后端数据库接入说明.md`：数据库与快照说明
