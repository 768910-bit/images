# 数据库配置

后端使用 SQLAlchemy 2.x 管理数据库连接和 ORM 模型。未配置 `DATABASE_URL` 时，默认使用 `backend/aquaops.db` 这个本地 SQLite 文件，首次启动会自动建表并灌入演示数据。

数据库接入的完整实现说明、表结构、接口落库方式、迁移和运维注意事项见 [后端数据库接入说明.md](./后端数据库接入说明.md)。

## 默认 SQLite

直接启动即可：

```powershell
cd backend
.\.venv\Scripts\python.exe run.py
```

数据库文件位置：

```text
backend/aquaops.db
```

该文件已加入 `.gitignore`，不会进入版本库。

## 连接外部数据库

通过 `DATABASE_URL` 环境变量指定连接串。首次连接空库时，后端会自动建表；如果需要保留目标库已有结构并禁止写入演示数据，可同时设置 `AQUAOPS_AUTO_SEED=false`。

PostgreSQL 示例：

```powershell
.\.venv\Scripts\python.exe -m pip install "psycopg[binary]"
$env:DATABASE_URL = "postgresql+psycopg://用户名:密码@主机:5432/数据库名"
$env:AQUAOPS_AUTO_SEED = "false"
.\.venv\Scripts\python.exe run.py
```

MySQL 示例：

```powershell
.\.venv\Scripts\python.exe -m pip install pymysql
$env:DATABASE_URL = "mysql+pymysql://用户名:密码@主机:3306/数据库名?charset=utf8mb4"
$env:AQUAOPS_AUTO_SEED = "false"
.\.venv\Scripts\python.exe run.py
```

## 当前表结构

| 表名 | 用途 |
| --- | --- |
| `users` | 登录账号、密码哈希、姓名和角色 |
| `monitoring_points` | 最新监测点数据 |
| `monitoring_series` | 趋势图序列定义 |
| `trend_samples` | 1 小时、24 小时和 7 天趋势样本 |
| `alarms` | 告警及确认状态 |
| `ai_analysis_tasks` | AI 分析任务和进度 |
| `saved_analyses` | 已保存分析记录 |
| `business_snapshots` | 总览、工艺和优化结果快照 |

## 验证连接

启动后访问：

```text
http://127.0.0.1:9000/api/health
```

返回中的 `database` 字段为 `ok` 表示数据库连接正常。

当前使用 `create_all` 完成首次建表，适合本地和联调环境。正式环境修改表结构时，应引入 Alembic 迁移，避免依赖自动建表。
